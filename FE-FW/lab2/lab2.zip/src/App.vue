<script setup>
import { ref } from "vue";
import Bai1 from "./components/Bai1.vue";
import Bai2 from "./components/Bai2.vue";
import Bai3 from "./components/Bai3.vue";
import Bai4 from "./components/Bai4.vue";

const isActive = ref(false);
const fontSize = ref(16);
</script>

<template>
  <Bai1 />
  <Bai2 />
  <Bai3 />
  <Bai4 />
</template>

<script setup>
import Bai1 from "./components/Bai1.vue";
import Bai2 from "./components/Bai2.vue";
import Bai3 from "./components/Bai3.vue";
import Bai4 from "./components/Bai4.vue";
</script>

<template>
  <div id="app">
    <h1>Bai1</h1>
    <Bai1 />
    <hr />
    <h1>Bai2</h1>
    <Bai2 />
    <hr />
    <h1>Bai3</h1>
    <Bai3 />
    <hr />
    <h1>Bai4</h1>
    <Bai4 />
  </div>
</template>

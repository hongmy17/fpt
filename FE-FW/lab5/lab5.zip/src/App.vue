<template>
  <div class="container mt-4">
    <Bai2 @add-book="addBook" />
    <Bai1
      id="1"
      title="Cuốn sách 1"
      author="Tác giả A"
      :price="150000"
      category="Fiction"
    />

    <Bai4>
      <template #default="{ theme }">
        <h2 :class="theme">Chủ đề hiện tại: {{ theme }}</h2>
        <Bai3>
          <h5 class="card-title">Tiêu đề sách</h5>
          <h6 class="card-subtitle mb-2 text-muted">Tác giả: Tác giả A</h6>
          <p class="card-text">Giá: 150000 VND</p>
          <p class="card-text">Thể loại: Fiction</p>
        </Bai3>
      </template>
    </Bai4>
  </div>
</template>

<script setup>
import { ref } from "vue";
import Bai1 from "./components/Bai1.vue";
import Bai2 from "./components/Bai2.vue";
import Bai3 from "./components/Bai3.vue";
import Bai4 from "./components/Bai4.vue";

const books = ref([]);
const addBook = (book) => {
  books.value.push(book);
};
</script>

<template>
  <form @submit.prevent="submitForm" class="mb-4">
    <div class="mb-3">
      <input
        v-model="title"
        type="text"
        class="form-control"
        placeholder="Tiêu đề"
      />
    </div>
    <div class="mb-3">
      <input
        v-model="author"
        type="text"
        class="form-control"
        placeholder="Tác giả"
      />
    </div>
    <div class="mb-3">
      <input
        v-model.number="price"
        type="number"
        class="form-control"
        placeholder="Giá"
      />
    </div>
    <div class="mb-3">
      <input
        v-model="category"
        type="text"
        class="form-control"
        placeholder="Thể loại"
      />
    </div>
    <button type="submit" class="btn btn-primary">Thêm sách</button>
  </form>
</template>

<script setup>
import { ref, defineEmits } from "vue";
const emit = defineEmits();
const title = ref("");
const author = ref("");
const price = ref(0);
const category = ref("");
const submitForm = () => {
  emit("add-book", {
    title: title.value,
    author: author.value,
    price: price.value,
    category: category.value,
  });
  title.value = "";
  author.value = "";
  price.value = 0;
  category.value = "";
};
</script>

<template>
  <div class="card mb-3">
    <div class="card-body">
      <slot></slot>
    </div>
  </div>
</template>

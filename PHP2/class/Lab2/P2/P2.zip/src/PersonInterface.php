<?php

namespace App;

interface PersonInterface {
  public function getName();
  public function getAge();
  public function getInfo();
}
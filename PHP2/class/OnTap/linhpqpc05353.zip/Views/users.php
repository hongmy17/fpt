<ul>
  <?php foreach ($data as $product): ?>
    <li><?=$product["name"];?></li>
  <?php endforeach; ?>
</ul>
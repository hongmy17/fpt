<?php

namespace App\Model;

class User extends Model {
  protected $table = "user";
}
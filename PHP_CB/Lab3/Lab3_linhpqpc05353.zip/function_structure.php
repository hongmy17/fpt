<?php
function sumThreeNumbers($a, $b, $c) {
  return $a + $b + $c;
}

echo sumThreeNumbers(1,2,3) . "<br>";
echo sumThreeNumbers(2,3,4) . "<br>";
echo sumThreeNumbers(3,4,5) . "<br>";
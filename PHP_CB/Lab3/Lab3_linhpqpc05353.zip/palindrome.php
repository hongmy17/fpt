<?php
function isPalindrome($string) {
  $string = strtolower(str_replace(" ","", $string));
  return $string == strrev($string);
}

echo isPalindrome("madam") ? "madam la chuoi doi xung <br>" : "madam khong phai chuoi doi xung <br>";
echo isPalindrome("hello") ? "hello la chuoi doi xung <br>" : "hello khong phai chuoi doi xung <br>";
echo isPalindrome("A Santa at NASA") ? "A Santa at NASA la chuoi doi xung <br>" : "A Santa at NASA khong phai chuoi doi xung <br>";
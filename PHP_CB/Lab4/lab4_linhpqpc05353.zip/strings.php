<?php
$string1 = "Hello";
$string2 = "World";

echo $string1 . "<br>";
echo $string2 . "<br>";

$concatenatedString = $string1 . " " . $string2;
echo $concatenatedString ."<br>";

$length = strlen($concatenatedString);
echo "Do dai cua chuoi: " . $concatenatedString . "la: " . $length ."<br>";
<?php
$inputString = "Hom nay, troi nang dep";
$reversedString = strrev($inputString);

echo "<p>Original String: $inputString</p>";
echo "<p>Reversed String: $reversedString</p>";
<?php
function getStringLength($str) {
  return strlen($str);
}

echo getStringLength("Hello PHP");
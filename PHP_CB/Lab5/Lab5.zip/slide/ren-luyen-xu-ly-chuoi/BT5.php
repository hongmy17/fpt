<?php
function toLowerCase($string) {
  return strtolower($string);
}

function toUpperCase($string) {
  return strtoupper($string);
}

echo toLowerCase("Hello world");
echo toUpperCase("Hello world");
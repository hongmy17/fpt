<?php
function trimString($string) {
  return trim($string);
}

echo trimString("       hello world       ");
<?php

$number = 11;

if ($number > 0) {
  echo $number % 2 == 0 ? "$number la so chan" : "$number la so le";
} else {
  echo "'number' phai lon hon 0";
}